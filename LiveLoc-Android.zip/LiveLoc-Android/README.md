# LiveLoc-Android
LiveLoc Front-End for Android devices
